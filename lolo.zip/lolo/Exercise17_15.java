import java.io.*;
import java.util.Scanner;

public class Exercise17_15 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the encrypted file name: ");
        String inputFileName = input.nextLine();
        System.out.print("Enter the decrypted output file name: ");
        String outputFileName = input.nextLine();
        try (
            BufferedInputStream in = new BufferedInputStream(new FileInputStream(inputFileName));
            BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(outputFileName))
        ) {
            int value;
            while ((value = in.read()) != -1) {
                out.write(value - 5);
            }
            System.out.println("File decrypted successfully!");
        } catch (FileNotFoundException e) {
            System.out.println("Error: The encrypted file could not be found.");
        } catch (IOException e) {
            System.out.println("An I/O error occurred: " + e.getMessage());
        }
    }
}
